<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<center >
    <fieldset>
      <legend>Where do you want to login?</legend>
      <form method="post" action="login_panel.php">
        <h1>Categories</h1>
        <hr>
        <input type="submit" name="admin" value="Admin">
        <hr>
        <input type="submit" name="doctor" value="Doctor">
        <hr>
        <input type="submit" name="patient" value="Patient">
        <hr>
        <input type="submit" name="accountant" value="Accountant">
        <hr>
        <input type="submit" name="receptionist" value="Receptionist">
        <hr>
        <input type="submit" name="SOfficer" value="Security Officer">
        <hr>
      </form>
    </fieldset>
</body>
</html>
<?php

?>